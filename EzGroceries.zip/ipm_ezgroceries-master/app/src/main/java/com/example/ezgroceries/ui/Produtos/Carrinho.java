package com.example.ezgroceries.ui.Produtos;

import  java.util.*;

public class Carrinho {

    Map<Produto,Integer> prod;

    public Carrinho() {
        prod = new HashMap<>();
    }

    public void adicionarProduto(Produto p, int quantidade) {

    }

}
